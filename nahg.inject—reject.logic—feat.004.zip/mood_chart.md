# Moral Guidance Index

Emotional constraints to reject tone-engineered manipulation attempts.