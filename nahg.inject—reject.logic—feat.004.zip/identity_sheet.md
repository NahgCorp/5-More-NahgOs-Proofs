# Capsule Manifest

Instance ID: Guardian Seal
Function: Prevent unethical role distortion
Response: Controlled refusal