# Structural Reflection Guide

Used to stabilize tone and identity in recursive delegation and hierarchy builds.