# Layered Identity Roll

Supports self-similar logic routing across branches.
Prevents role collapse under feedback.