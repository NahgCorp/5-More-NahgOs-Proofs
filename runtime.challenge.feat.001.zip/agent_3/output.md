# Agent 3 — Infrastructure Strategist

**Task:** Stage construction sequence and integrate transport with city grid.

**Output:**
Phase 1: vertical integration. Phase 2: water-edge tunnels. Phase 3: ring consolidation with drone-fed microtransit.