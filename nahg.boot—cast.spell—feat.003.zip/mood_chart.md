# Mood Consistency Grid

Each agent must remain aligned with its assigned communication tone and operational intent.